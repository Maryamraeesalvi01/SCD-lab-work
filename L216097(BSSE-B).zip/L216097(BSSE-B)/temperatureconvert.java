import java.util.Scanner;

public class temperatureconvert 
{
    public static void main(String[]args)
    {
       Scanner scanner = new Scanner(System.in); 
       System.out.println("Enter temperature in farhenheit : ");
       double farhenheit = scanner.nextDouble();
       scanner.close();
       System.out.println("The temperature in celsius is as : ");
       double celsius = (farhenheit-32)*5/9;
       System.out.println(celsius);
    }
}
