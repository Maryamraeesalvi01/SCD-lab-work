import java.util.Scanner;

public class MultiplicationTable {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number to print its multiplicationtable : ");
        int number = scanner.nextInt();
        scanner.close();
        System.out.println("Multiplication Table for " + number + " is : ");
        for (int i = 1; i <= 10; i++) 
        {
            int result = number * i;
            System.out.println(number + " x " + i + " = " + result);
        }
    }
}
