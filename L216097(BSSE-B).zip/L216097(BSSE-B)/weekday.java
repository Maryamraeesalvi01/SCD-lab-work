import java.util.Scanner;
public class weekday 
{
    public static void main(String[]args)
    {
       Scanner scanner = new Scanner(System.in);
       System.out.println("Enter number number 1-7 to check corressponding weekday ");
       int num = scanner.nextInt();
       scanner.close();
       System.out.println("The weekday for "+num+" is : ");
       if(num==1)
       System.out.println("Monday");
       if(num==2)
       System.out.println("Tuesday");
       if(num==3)
       System.out.println("wednesday");
       if(num==4)
       System.out.println("Thursday");
       if(num==5)
       System.out.println("Friday");
       if(num==6)
       System.out.println("Saturday");
       if(num==7)
       System.out.println("Sunday");

    }
    
}
