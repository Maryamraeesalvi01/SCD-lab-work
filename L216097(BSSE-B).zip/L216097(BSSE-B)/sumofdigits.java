import java.util.Scanner;
public class sumofdigits 
{
    public static void main(String[]args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number between 0 to 1000 to sum its digits : ");
        int num = scanner.nextInt();
        scanner.close();
        int result;
        int sum=0;
        System.out.println("The sum of digits of "+num+" is : ");
        do{
         result=num%10;
        sum=sum+result;
        num=num/10;
        }while(num>0);
        System.out.println(sum);
    }
    
}
