import java.util.Scanner;
public class calculator 
{
    public static void main(String[]args)
    {
    Scanner scanner = new Scanner(System.in);
    System.out.println("****CALCULATOR*****");
    System.out.println("Please Enter values for two oprands a and b : ");
    double a=scanner.nextDouble();
    double b =scanner.nextDouble();
    char operator;
    double result=0;
    System.out.println("The basic operations to perform are '*,+,-,/' ,  Enter the operator to use :  ");
    operator=scanner.next().charAt(0);
    if(operator!='+'&&operator!='*'&&operator!='-'&&operator!='/')
    {
        System.out.println("Invalid operator!");
    }
    scanner.close();
    if(operator=='*')
    {
        result=a*b;
        System.out.println("The output result is = "+ result);
    }
    if(operator=='/')
    {
        result=a/b;
        System.out.println("The output result is = "+ result);
    }
    if(operator=='+')
    {
        result=a+b;
        System.out.println("The output result is = "+ result);
    }
    if(operator=='-')
    {
        result=a-b;
        System.out.println("The output result is = "+ result);
    }
    }
    
}
