import java.util.Scanner;
public class additionofoddintegers 
{
    public static void main(String[]args)
    {
        int sum=0;
        Scanner scanner = new Scanner(System.in);
        int array[]=new int[100];
        System.out.println("Enter the size of array : ");
        int num = scanner.nextInt();
        System.out.println("Enter the numbers of array : ");
        for (int i=0; i<=num; i++)
        {
            array[i]=scanner.nextInt();
        }
        scanner.close();
        System.out.println("Array is as : ");
        for(int i=0; i<=num; i++)
        {
        System.out.println(array[i]);
        }
        System.out.println("The sum of odd itegers in array is : ");
        for(int i=0; i<=num; i++)
        {
            if(array[i]%2==0)
            {
            array[i]=array[i+1];
            }
            else
            {
            sum=sum+array[i];
            }
        }
        System.out.println(sum);

    }
    
}
